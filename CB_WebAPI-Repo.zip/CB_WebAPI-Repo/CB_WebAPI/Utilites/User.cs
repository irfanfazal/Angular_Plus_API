﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CB_DataEntity.Model
{
   public class User
    {
        public string username { get; set; }
        public string password { get; set; }

    }
}
