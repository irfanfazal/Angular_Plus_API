﻿namespace CB_WebAPI.Controllers
{
    public class Member
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}